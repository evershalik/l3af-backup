# xdp-root

Root program for chaining multiple xdp programs

## How to build

To build run:

```
make
```

See our [L3AF Development Environment](https://github.com/l3af-project/l3af-arch/blob/main/dev_environment/) for a quick and easy way to try out L3AF on your local machine.

## Usage:
```
xdp_root --cmd <start/stop> --iface <iface>
```
